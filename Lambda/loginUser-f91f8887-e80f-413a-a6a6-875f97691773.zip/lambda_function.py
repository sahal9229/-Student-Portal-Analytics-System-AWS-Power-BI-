import json
import boto3

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('Students')

def lambda_handler(event, context):

    body = json.loads(event['body'])

    email = body['email']
    password = body['password']

    response = table.scan(
        FilterExpression='email = :e',
        ExpressionAttributeValues={
            ':e': email
        }
    )

    items = response.get('Items', [])

    if len(items) == 0:
        return {
            'statusCode': 404,
            'headers': {
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'message': 'User not found'
            })
        }

    student = items[0]

    if student['password'] != password:
        return {
            'statusCode': 401,
            'headers': {
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'message': 'Invalid password'
            })
        }

    return {
        'statusCode': 200,
        'headers': {
            'Access-Control-Allow-Origin': '*'
        },
        'body': json.dumps({
            'message': 'Login successful',
            'user': {
                'studentId': student.get('studentId'),
                'fullName': student.get('fullName'),
                'email': student.get('email'),
                'city': student.get('city'),
                'age': int(student.get('age', 0)),
                'course': student.get('course', ''),
                'learningGoal': student.get('learningGoal', '')
            }
        })
    }