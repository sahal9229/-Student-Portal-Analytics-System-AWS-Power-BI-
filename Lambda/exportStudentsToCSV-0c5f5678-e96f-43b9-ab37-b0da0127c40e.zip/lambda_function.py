import boto3
import csv
import io
import traceback

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('Students')

s3 = boto3.client('s3')

BUCKET_NAME = 'studentportal-analytics-sahal'
FILE_NAME = 'students.csv'


def lambda_handler(event, context):
    try:
        response = table.scan()
        students = response.get('Items', [])

        output = io.StringIO()
        writer = csv.writer(output)

        writer.writerow([
            'studentId',
            'fullName',
            'email',
            'city',
            'age',
            'course',
            'learningGoal'
        ])

        for student in students:
            writer.writerow([
                student.get('studentId', ''),
                student.get('fullName', ''),
                student.get('email', ''),
                student.get('city', ''),
                student.get('age', ''),
                student.get('course', ''),
                student.get('learningGoal', '')
            ])

        s3.put_object(
            Bucket=BUCKET_NAME,
            Key=FILE_NAME,
            Body=output.getvalue(),
            ContentType='text/csv'
        )

        return {
            'statusCode': 200,
            'body': 'CSV uploaded successfully'
        }

    except Exception as e:
        print(traceback.format_exc())

        return {
            'statusCode': 500,
            'body': str(e)
        }