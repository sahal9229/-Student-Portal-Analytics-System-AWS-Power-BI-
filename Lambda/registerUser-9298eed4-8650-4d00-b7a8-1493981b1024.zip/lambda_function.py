import json
import boto3
import uuid

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('Students')

def lambda_handler(event, context):

    body = json.loads(event['body'])

    student_id = str(uuid.uuid4())

    table.put_item(
        Item={
            'studentId': student_id,
            'fullName': body['fullName'],
            'email': body['email'],
            'password': body['password'],
            'city': body['city'],
            'age': body.get('age'),
            'course': body.get('course'),
            'learningGoal': body.get('learningGoal')
        }
    )

    return {
        'statusCode': 200,
        'headers': {
            'Access-Control-Allow-Origin': '*'
        },
        'body': json.dumps({
            'message': 'Student registered successfully',
            'studentId': student_id
        })
    }