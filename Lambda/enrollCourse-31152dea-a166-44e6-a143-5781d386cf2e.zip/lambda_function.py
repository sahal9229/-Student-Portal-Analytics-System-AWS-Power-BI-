import json
import boto3

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('Students')

def lambda_handler(event, context):

    body = json.loads(event['body'])

    student_id = body['studentId']
    course = body['course']

    table.update_item(
        Key={
            'studentId': student_id
        },
        UpdateExpression="SET course = :c",
        ExpressionAttributeValues={
            ':c': course
        }
    )

    return {
        'statusCode': 200,
        'headers': {
            'Access-Control-Allow-Origin': '*'
        },
        'body': json.dumps({
            'message': 'Course enrolled successfully'
        })
    }